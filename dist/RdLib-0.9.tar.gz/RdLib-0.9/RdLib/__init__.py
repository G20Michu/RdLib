# RdLib/__init__.py
from .Rd import Rd